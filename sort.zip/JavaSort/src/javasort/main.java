/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javasort;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/**
 *
 * @author Lab
 */
public class main extends javax.swing.JFrame {

    List<JLabel> arregloLabel;
    int[] arreglo;
    boolean arregloCreado = false;

    public main() {
        initComponents();
        initArregloLabel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblElemento1 = new javax.swing.JLabel();
        lblElemento2 = new javax.swing.JLabel();
        lblElemento3 = new javax.swing.JLabel();
        lblElemento4 = new javax.swing.JLabel();
        lblElemento5 = new javax.swing.JLabel();
        lblElemento6 = new javax.swing.JLabel();
        lblElemento7 = new javax.swing.JLabel();
        lblElemento8 = new javax.swing.JLabel();
        lblElemento9 = new javax.swing.JLabel();
        lblElemento10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnGenerarArray = new javax.swing.JButton();
        btnInsertion = new javax.swing.JButton();
        btnShell = new javax.swing.JButton();
        btnMerge = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("ARRAY"));
        jPanel1.setLayout(new java.awt.GridLayout(1, 0));

        lblElemento1.setText("0");
        jPanel1.add(lblElemento1);

        lblElemento2.setText("0");
        jPanel1.add(lblElemento2);

        lblElemento3.setText("0");
        jPanel1.add(lblElemento3);

        lblElemento4.setText("0");
        jPanel1.add(lblElemento4);

        lblElemento5.setText("0");
        jPanel1.add(lblElemento5);

        lblElemento6.setText("0");
        jPanel1.add(lblElemento6);

        lblElemento7.setText("0");
        jPanel1.add(lblElemento7);

        lblElemento8.setText("0");
        jPanel1.add(lblElemento8);

        lblElemento9.setText("0");
        jPanel1.add(lblElemento9);

        lblElemento10.setText("0");
        jPanel1.add(lblElemento10);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("BOTONES"));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        btnGenerarArray.setText("GENERAR ARRAY");
        btnGenerarArray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarArrayActionPerformed(evt);
            }
        });
        jPanel2.add(btnGenerarArray);

        btnInsertion.setText("INSERTION SORT");
        btnInsertion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertionActionPerformed(evt);
            }
        });
        jPanel2.add(btnInsertion);

        btnShell.setText("SHELL SORT");
        btnShell.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShellActionPerformed(evt);
            }
        });
        jPanel2.add(btnShell);

        btnMerge.setText("MERGE SORT");
        btnMerge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMergeActionPerformed(evt);
            }
        });
        jPanel2.add(btnMerge);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 262, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenerarArrayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarArrayActionPerformed
        generarArreglo();
    }//GEN-LAST:event_btnGenerarArrayActionPerformed

    private void btnInsertionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertionActionPerformed
        if (!arregloCreado) {
            System.out.println("Arreglo no creado");
            generarArreglo();
            arregloCreado = true;
        } else {
            int auxI, auxN;

            for (int i = 1; i < arreglo.length; i++) {
                auxI = i;
                while (auxI - 1 != -1) {
                    if (arreglo[auxI] < arreglo[auxI - 1]) {
                        auxN = arreglo[auxI];
                        arreglo[auxI] = arreglo[auxI - 1];
                        arreglo[auxI - 1] = auxN;

                        auxI--;
                    } else {
                        break;
                    }
                }
            }
            mostrarValoresArreglo();
        }
    }//GEN-LAST:event_btnInsertionActionPerformed

    private void btnMergeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMergeActionPerformed
        if (!arregloCreado) {
            System.out.println("Arreglo no creado");
            generarArreglo();
            arregloCreado = true;
        } else {
            mergeSort.mergeSort(arreglo, arreglo.length);
            mostrarValoresArreglo();
        }
    }//GEN-LAST:event_btnMergeActionPerformed

    private void btnShellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShellActionPerformed
        if (!arregloCreado) {
            System.out.println("Arreglo no creado");
            generarArreglo();
            arregloCreado = true;
        } else {
            int n = arreglo.length;

            // Se empieza con un gap grande, luego se reduce
            for (int gap = n / 2; gap > 0; gap /= 2) {
                for (int i = gap; i < n; i += 1) {
                    int temp = arreglo[i];

                    // Se revuelvn los numeros hasta que encuentran su posicion en el arreglo
                    int j;
                    for (j = i; j >= gap && arreglo[j - gap] > temp; j -= gap) {
                        // Si el numero temporal es mayor al seleccionado entonces se cambian
                        arreglo[j] = arreglo[j - gap];
                    }
                    
                    arreglo[j] = temp;
                }
            }
        }
        mostrarValoresArreglo();
    }//GEN-LAST:event_btnShellActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerarArray;
    private javax.swing.JButton btnInsertion;
    private javax.swing.JButton btnMerge;
    private javax.swing.JButton btnShell;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblElemento1;
    private javax.swing.JLabel lblElemento10;
    private javax.swing.JLabel lblElemento2;
    private javax.swing.JLabel lblElemento3;
    private javax.swing.JLabel lblElemento4;
    private javax.swing.JLabel lblElemento5;
    private javax.swing.JLabel lblElemento6;
    private javax.swing.JLabel lblElemento7;
    private javax.swing.JLabel lblElemento8;
    private javax.swing.JLabel lblElemento9;
    // End of variables declaration//GEN-END:variables

    private void generarArreglo() {
        arreglo = new int[10];
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = (int) (Math.random() * 10);
        }
        mostrarValoresArreglo();
    }

    private void initArregloLabel() {
        arregloLabel = new ArrayList<>();

        arregloLabel.add(lblElemento1);
        arregloLabel.add(lblElemento2);
        arregloLabel.add(lblElemento3);
        arregloLabel.add(lblElemento4);
        arregloLabel.add(lblElemento5);
        arregloLabel.add(lblElemento6);
        arregloLabel.add(lblElemento7);
        arregloLabel.add(lblElemento8);
        arregloLabel.add(lblElemento9);
        arregloLabel.add(lblElemento10);
    }

    public void mostrarValoresArreglo() {
        for (int i = 0; i < arreglo.length; i++) {
            arregloLabel.get(i).setText(arreglo[i] + "");
        }
    }
}
